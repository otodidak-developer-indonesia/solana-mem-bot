require('dotenv').config();

const { fetchNewTokens } = require('./src/api');
const { evaluateTokens } = require('./src/analyzer');

async function screeningRunner() {
  try {
    const tokens = await fetchNewTokens();
    if (!tokens.length) {
      console.log('No new tokens fetched.');
      return;
    }
    const evaluated = await evaluateTokens(tokens);
    if (evaluated.length) {
      console.log(`Tokens meeting criteria: ${evaluated.length}`);
    } else {
      console.log('No tokens meet screening criteria.');
    }
  } catch (error) {
    console.error('Screening error:', error);
  }
}

screeningRunner();
setInterval(screeningRunner, 60000);
