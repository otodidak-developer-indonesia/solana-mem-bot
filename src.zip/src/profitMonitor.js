const connection = require('./db').promise();

async function monitorWinrateAndProfit() {
  try {
    const [rows] = await connection.query(`
      SELECT 
        COUNT(*) AS total_sold,
        SUM(CASE WHEN ((sell_price - purchase_price) * quantity_sold) > 0 THEN 1 ELSE 0 END) AS total_wins,
        SUM(IFNULL((sell_price - purchase_price) * quantity_sold, 0)) AS total_realized_profit
      FROM transactions
      WHERE is_sold = 1 OR partial_sold = 1;
    `);

    const row = rows && rows[0];
    if (!row) {
      console.log('No sold transactions yet.');
      return;
    }

    const { total_sold, total_wins, total_realized_profit } = row;
    const winrate = total_sold > 0 ? (total_wins / total_sold) * 100 : 0;
    const totalProfitNum = Number(total_realized_profit) || 0;

    console.log('----- Realized Profit & Winrate Summary -----');
    console.log(`Total Sold Transactions (partial+full): ${total_sold}`);
    console.log(`Winning Transactions (partial+full): ${total_wins}`);
    console.log(`Winrate: ${winrate.toFixed(2)}%`);
    console.log(`Total Realized Profit/Loss: $${totalProfitNum.toFixed(6)}`);
    console.log('---------------------------------------------');
  } catch (error) {
    console.error('Error monitoring winrate and profit:', error);
  }
}

module.exports = {
  monitorWinrateAndProfit,
};
