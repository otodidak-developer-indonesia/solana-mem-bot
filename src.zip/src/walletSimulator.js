const connection = require('./db').promise();

async function getWalletBalance() {
  const [rows] = await connection.query('SELECT balance FROM wallet WHERE id = 1 LIMIT 1');
  if (rows.length === 0) {
    await connection.query('INSERT INTO wallet (balance) VALUES (20.0)');
    return 20.0;
  }
  return Number(rows[0].balance);
}

async function updateWalletBalance(newBalance) {
  await connection.query('UPDATE wallet SET balance = ? WHERE id = 1', [newBalance]);
}

async function simulateWalletBalanceAndSave() {
  try {
    let balance = await getWalletBalance();

    const [transactions] = await connection.query(`
      SELECT purchase_price, quantity, quantity_sold, sell_price
      FROM transactions
    `);

    let calculatedBalance = 20.0;

    for (const tx of transactions) {
      const purchasePrice = Number(tx.purchase_price) || 0;
      const quantity = Number(tx.quantity) || 0;
      const purchaseCost = purchasePrice * quantity;
      calculatedBalance -= purchaseCost;

      const soldQty = Number(tx.quantity_sold) || 0;
      const sellPrice = Number(tx.sell_price) || 0;
      if (soldQty > 0 && sellPrice > 0) {
        const sellProceeds = sellPrice * soldQty;
        calculatedBalance += sellProceeds;
      }
    }

    await updateWalletBalance(calculatedBalance);
    balance = calculatedBalance;

    console.log('=== Wallet Balance (Persisted) ===');
    console.log(`Current Balance: $${balance.toFixed(4)}`);
    console.log(`Profit/Loss: $${(balance - 20).toFixed(4)}`);
    console.log('==================================');

    return {
      currentBalance: balance,
      profitLoss: balance - 20,
    };
  } catch (error) {
    console.error('Error simulating wallet balance:', error);
  }
}

module.exports = {
  simulateWalletBalanceAndSave,
  getWalletBalance,
  updateWalletBalance,
};
