const connection = require('./db');
const { getPricesForMultipleTokens } = require('./api');

async function monitorTrailingStop() {
  try {
    const [rows] = await new Promise((resolve, reject) => {
      const query = `
        SELECT 
          t.id AS transaction_id, 
          t.token_id, 
          t.mint_address, 
          t.purchase_price, 
          t.quantity, 
          t.quantity_sold, 
          t.partial_sold, 
          t.highest_price,
          tokens.symbol
        FROM transactions t
        JOIN tokens ON tokens.id = t.token_id
        WHERE t.is_sold = 0
      `;
      connection.query(query, (err, results) => {
        if (err) return reject(err);
        resolve([results]);
      });
    });

    if (!rows.length) {
      console.log('No active transactions to monitor.');
      return;
    }

    const mintAddresses = rows.map(r => r.mint_address.trim());
    const pricesData = await getPricesForMultipleTokens(mintAddresses);

    const logTable = [];

    for (const tx of rows) {
      const mintKey = Object.keys(pricesData).find(
        (key) => key.toLowerCase() === tx.mint_address.toLowerCase()
      );

      if (!mintKey) {
        console.log(`No price data for mintAddress: ${tx.mint_address}`);
        continue;
      }

      const priceInfo = pricesData[mintKey];
      let currentPrice = priceInfo?.price ?? 0;

      const purchasePriceRaw = tx.purchase_price;
      const purchasePrice = typeof purchasePriceRaw === 'number' ? purchasePriceRaw : Number(purchasePriceRaw) || 0;

      let highestPrice = tx.highest_price !== null ? Number(tx.highest_price) : purchasePrice;

      const changePercent = purchasePrice > 0 ? ((currentPrice - purchasePrice) / purchasePrice) * 100 : 0;

      logTable.push({
        ID: tx.transaction_id,
        Symbol: tx.symbol,
        'Purchase Price': purchasePrice.toFixed(8),
        'Current Price': currentPrice.toFixed(8),
        'Highest Price': highestPrice.toFixed(8),
        '% Change': changePercent.toFixed(2) + '%',
      });

      if (currentPrice === 0) {
        currentPrice = 0.0000001; // harga jual paksa saat rugpull diubah jadi 0.0000001
        const updateQuery = `
          UPDATE transactions
          SET quantity_sold = quantity, is_sold = 1, sell_price = ?, sell_time = NOW()
          WHERE id = ?
        `;
        await new Promise((resolve, reject) => {
          connection.query(updateQuery, [currentPrice, tx.transaction_id], (err) => {
            if (err) return reject(err);
            resolve();
          });
        });
        console.log(`Price zero detected for tx ${tx.transaction_id} (${tx.symbol}), full sell at forced price 0.0000001`);
        continue;
      }

      const quantity = tx.quantity;
      const quantitySold = tx.quantity_sold || 0;
      const quantityRemaining = quantity - quantitySold;

      if (quantityRemaining <= 0) {
        console.log(`No quantity remaining to sell for transaction ${tx.transaction_id}`);
        continue;
      }

      const targetPrice = purchasePrice * 2;

      if (currentPrice > highestPrice) {
        highestPrice = currentPrice;
        const updateHighQuery = `
          UPDATE transactions
          SET highest_price = ?
          WHERE id = ?
        `;
        await new Promise((resolve, reject) => {
          connection.query(updateHighQuery, [highestPrice, tx.transaction_id], (err) => {
            if (err) return reject(err);
            resolve();
          });
        });
      }

      if (currentPrice >= targetPrice && !tx.partial_sold) {
        const sellQty = quantity / 2;
        const newQuantitySold = quantitySold + sellQty;
        const isSoldFlag = newQuantitySold >= quantity ? 1 : 0;

        const updateQuery = `
          UPDATE transactions
          SET quantity_sold = ?, sell_price = ?, sell_time = NOW(), is_sold = ?, partial_sold = 1
          WHERE id = ?
        `;

        await new Promise((resolve, reject) => {
          connection.query(updateQuery, [newQuantitySold, currentPrice, isSoldFlag, tx.transaction_id], (err) => {
            if (err) return reject(err);
            resolve();
          });
        });

        console.log(`Moobag partial sell 50% qty (${sellQty.toFixed(4)}) for transaction ${tx.transaction_id} (${tx.symbol}) at price ${currentPrice}`);
        continue;
      }

      if (currentPrice <= highestPrice * 0.75) {
        if (quantityRemaining > 0) {
          const updateQuery = `
            UPDATE transactions
            SET quantity_sold = quantity, is_sold = 1, sell_price = ?, sell_time = NOW()
            WHERE id = ?
          `;

          await new Promise((resolve, reject) => {
            connection.query(updateQuery, [currentPrice, tx.transaction_id], (err) => {
              if (err) return reject(err);
              resolve();
            });
          });

          console.log(`Trailing stop triggered, selling remaining qty for transaction ${tx.transaction_id} (${tx.symbol}) at price ${currentPrice}`);
        }
      }
    }

    console.table(logTable);

  } catch (error) {
    console.error('Monitoring error:', error);
  }
}

module.exports = {
  monitorTrailingStop,
};
