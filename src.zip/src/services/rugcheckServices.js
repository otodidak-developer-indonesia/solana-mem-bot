// src/services/rugcheckService.js
import axios from 'axios';

export const checkRugReport = async (mint) => {
  try {
    const response = await axios.get(`https://api.rugcheck.xyz/v1/tokens/${mint}/report`);
    return response.data;
  } catch (err) {
    console.error(`❌ Rugcheck API error for ${mint}:`, err.message);
    return null;
  }
};
