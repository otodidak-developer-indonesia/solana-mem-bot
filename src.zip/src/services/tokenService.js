// src/services/tokenService.js
import { sequelize } from '../config/database.js';
import { Sequelize } from 'sequelize';

export const checkExist = async (mint) => {
  const [rows] = await sequelize.query(
    `SELECT mint FROM solana_tokens WHERE mint = :mint`,
    {
      replacements: { mint },
      type: Sequelize.QueryTypes.SELECT,
    }
  );
  return rows;
};

export const insertToken = async (token) => {
  if (!token?.token?.mint || !token?.token?.name || !token?.token?.symbol) {
    console.warn('⚠️ Skipping token with missing info:', token?.token);
    return;
  }

  const transaction = await sequelize.transaction();
  try {
    await sequelize.query(
      `INSERT INTO solana_tokens (mint, name, symbol, description, created_at_js)
       VALUES (:mint, :name, :symbol, :description, :createdAtJs)`,
      {
        replacements: {
          mint: token.token.mint,
          name: token.token.name,
          symbol: token.token.symbol,
          description: token.token.description || null,
          createdAtJs: Math.floor(Date.now() / 1000),
        },
        transaction,
      }
    );
    await transaction.commit();
    console.log(`✅ Token saved: ${token.token.mint}`);
  } catch (err) {
    await transaction.rollback();
    console.error('❌ Failed to save token:', err.message);
  }
};


export const updateTokenStatus = async (mint, status) => {
  await sequelize.query(`
    UPDATE solana_tokens SET status = :status WHERE mint = :mint
  `, {
    replacements: { status, mint },
  });
};

export const updateTokenMetrics = async (mint, price, marketCap) => {
  await sequelize.query(`
    UPDATE solana_tokens 
    SET status = 2, price = :price, lowest_price = :lowestPrice, market_cap = :marketCap 
    WHERE mint = :mint
  `, {
    replacements: {
      price,
      lowestPrice: price,
      marketCap,
      mint
    }
  });
};

export const getTokensToMonitor = async () => {
  return await sequelize.query(
    `SELECT * FROM solana_tokens WHERE status = 2`,
    { type: Sequelize.QueryTypes.SELECT }
  );
};

export const updateTokenHigh = async (mint, price, timestamp) => {
  await sequelize.query(`
    UPDATE solana_tokens 
    SET highest_price = :price, highest_time = :timestamp 
    WHERE mint = :mint
  `, {
    replacements: { price, timestamp, mint },
  });
};

export const updateTokenLow = async (mint, price, timestamp) => {
  await sequelize.query(`
    UPDATE solana_tokens 
    SET lowest_price = :price, lowest_time = :timestamp 
    WHERE mint = :mint
  `, {
    replacements: { price, timestamp, mint },
  });
};

export const markTakeProfit = async (mint) => {
  await updateTokenStatus(mint, 3);
};

export const markStopLoss = async (mint) => {
  await updateTokenStatus(mint, 4);
};

export const countTP = async () => {
  const [result] = await sequelize.query(`
    SELECT COUNT(*) as count FROM solana_tokens WHERE status = 3
  `, { type: Sequelize.QueryTypes.SELECT });
  return result.count;
};

export const countSL = async () => {
  const [result] = await sequelize.query(`
    SELECT COUNT(*) as count FROM solana_tokens WHERE status = 4
  `, { type: Sequelize.QueryTypes.SELECT });
  return result.count;
};
