// src/services/solanaTrackerService.js
import axios from 'axios';
import dotenv from 'dotenv';

const API_KEY = process.env.API_KEY_SOLANATRACKER;
export const fetchLatestTokens = async () => {
  try {
    const res = await axios.get('https://data.solanatracker.io/tokens/latest', {
      headers: {
        Accept: 'application/json',
        'x-api-key': process.env.API_KEY_SOLANATRACKER,
      },
      timeout: 10000,
    });

    console.log('📦 SolanaTracker response:', typeof res.data, Array.isArray(res.data), res.data?.length);
    return res.data;
  } catch (err) {
    console.error('❌ Failed to fetch from SolanaTracker:', err.message);
    return [];
  }
};


export const fetchTokenPrice = async (mint) => {
  const res = await axios.get(`https://data.solanatracker.io/price?token=${mint}`, {
    headers: {
      Accept: 'application/json',
      'x-api-key': process.env.API_KEY_SOLANATRACKER,
    },
    timeout: 10000,
  });
  return parseFloat(res.data.price);
};
