const connection = require('./db');

function safeValue(val, defaultValue = null) {
  return val === undefined || val === null ? defaultValue : val;
}

const saveTransaction = (tokenId, token, purchasePrice, quantity) => {
  purchasePrice = safeValue(purchasePrice);
  quantity = safeValue(quantity);
  const mintAddress = safeValue(token.token.mint, null);
  const purchaseTime = new Date().toISOString().slice(0, 19).replace('T', ' ');

  return new Promise((resolve, reject) => {
    const checkQuery = `
      SELECT id FROM transactions 
      WHERE mint_address = ? 
      LIMIT 1
    `;

    connection.query(checkQuery, [mintAddress], (err, results) => {
      if (err) {
        console.error('Error checking existing transaction:', err);
        return reject(err);
      }

      if (results.length > 0) {
        console.log(`Transaction with mint_address ${mintAddress} already exists, skipping insert.`);
        return resolve();
      }

      const insertQuery = `
        INSERT INTO transactions (token_id, purchase_price, quantity, quantity_sold, mint_address, purchase_time)
        VALUES (?, ?, ?, 0, ?, ?)
      `;

      const values = [tokenId, purchasePrice, quantity, mintAddress, purchaseTime];

      connection.execute(insertQuery, values, (err2) => {
        if (err2) {
          console.error('Error saving transaction:', err2);
          return reject(err2);
        }
        console.log(`Transaction saved for token ${token.token.name} (${token.token.symbol})`);
        resolve();
      });
    });
  });
};

module.exports = {
  saveTransaction,
};
