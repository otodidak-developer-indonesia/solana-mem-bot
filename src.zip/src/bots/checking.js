// src/bots/checking.js
import { sequelize } from '../config/database.js';
import { checkRugReport } from '../services/rugcheckServices.js';
import { sendTelegramNotification } from '../utils/telegram.js';
import { updateTokenStatus, updateTokenMetrics } from '../services/tokenService.js';
import { Sequelize } from 'sequelize';

const fetchPendingToken = async () => {
  const [rows] = await sequelize.query(`
    SELECT mint FROM solana_tokens WHERE status = 0 LIMIT 1
  `, {
    type: Sequelize.QueryTypes.SELECT,
  });
  return rows || null;
};

const processToken = async (mint) => {
  const report = await checkRugReport(mint);
  if (!report) return;

  const noWhaleHolder = report.topHolders && Array.isArray(report.topHolders) 
  ? !report.topHolders.some(h => h.pct > 25) 
  : false;
  const noSuspiciousCreator = !report.creatorTokens?.some(t => t.marketCap < 50000);
  
  const holdersOk = report.totalHolders >= 75 && report.totalHolders <= 1200
  const price = report.price;
  const marketCap = price * report.token.supply / 1_000_000;

  console.log(`[CHECKING] ${mint} | ${noWhaleHolder} | ${noSuspiciousCreator} | ${holdersOk}`);
  if (noWhaleHolder && noSuspiciousCreator && holdersOk) {
    await updateTokenMetrics(mint, price, marketCap);
    await sendTelegramNotification(mint, marketCap);
  } else {
    await updateTokenStatus(mint, 1); // Not qualified
  }
};

const loopChecking = async () => {
  const token = await fetchPendingToken();
  const mint = token?.mint
  if (!mint) return;
  await processToken(mint);
};

const main = async () => {
  await sequelize.authenticate();
  console.log('✅ Database connected. Starting checking bot...');
  await loopChecking();
  setInterval(loopChecking, 5000); // every 5s
};

main();
