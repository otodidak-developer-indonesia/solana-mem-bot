import { sequelize } from '../config/database.js';
import { checkExist, insertToken } from '../services/tokenService.js';
import { fetchLatestTokens } from '../services/solanaTrackerService.js';

const evaluateToken = (token) => {
  const pool = token.pools?.[0];
  if (!pool) return null;

  const now = Date.now();
  const tokenAgeMinutes = (now - pool.createdAt) / (1000 * 60);

  const marketCapSOL = pool.marketCap?.quote ?? 0;
  const liquiditySOL = pool.liquidity?.quote ?? 0;
  const volume = pool.txns?.volume ? pool.txns.volume : 0;

  const buys = pool.txns?.buys ?? 0;
  const sells = pool.txns?.sells ?? 0;
  const totalTx = pool.txns?.total ?? 1;
  const buyRatio = (buys / totalTx) * 100;

  const devHasSold = sells > 0 && token.token?.creation?.creator === pool.deployer;
  const isRenounced =
    pool.security?.freezeAuthority === null &&
    pool.security?.mintAuthority === null;
  const isListedOnRaydium = pool.market !== "pumpfun";
  const socialOk = token.token.strictSocials?.twitter != null;

  return {
    marketCapOk: marketCapSOL >= 50 && marketCapSOL <= 1000,
    buyRatioOk: buyRatio >= 65,
    liquidityOk: liquiditySOL >= 3,
    ageOk: tokenAgeMinutes <= 45,
    // raydiumOk: isListedOnRaydium,
    devNotSelling: !devHasSold,
    renouncedOk: isRenounced,
    volumeOk: volume >= 2000,
    socialOk: socialOk,
  };
};

const evaluateTokens = (tokens) => {
  const criteriaKeys = [
    "marketCapOk",
    "buyRatioOk",
    // "holdersOk",
    "liquidityOk",
    "ageOk",
    // "raydiumOk",
    "devNotSelling",
    "renouncedOk",
    "volumeOk",
    "socialOk"
  ];

  const summary = {};
  criteriaKeys.forEach(key => {
    summary[key] = { true: 0, false: 0 };
  });

  const evaluated = tokens.map(token => {
    const result = evaluateToken(token);
    if (!result) return null;

    for (const key of criteriaKeys) {
      summary[key][result[key] ? "true" : "false"]++;
    }

    return { token, result };
  }).filter(Boolean);

  return { evaluated, summary };
};

const processTokens = async () => {
  try {
    const tokens = await fetchLatestTokens();
    if (!tokens || !Array.isArray(tokens)) {
      console.log('No tokens fetched.');
      return;
    }

    const { evaluated, summary } = evaluateTokens(tokens);

    console.log("🔎 Evaluation Summary:");
    console.table(summary);

    for (const { token, result } of evaluated) {
      const passed = Object.values(result).every(v => v === true);
      if (passed) {
        const exists = await checkExist(token.token.mint);
        if (!exists) {
          await insertToken(token);
          console.log(`✅ Inserted: ${token.token.symbol}`);
        } else {
          console.log(`⚠️ Already exists: ${token.token.symbol}`);
        }
      } else {
        // console.log(`❌ Skipped (not passed): ${token.token.symbol}`);
      }
    }
  } catch (err) {
    console.error('[SCREENING ERROR] Error in screening loop:', err.message);
  }
};

const main = async () => {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connected. Starting screening bot...');
    await processTokens();
    setInterval(processTokens, 60000); // every 60 seconds
  } catch (err) {
    console.error('❌ Failed to start bot:', err.message);
    await sequelize.close();
  }
};

main();
