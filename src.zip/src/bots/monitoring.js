// src/bots/monitoring.js
import { sequelize } from '../config/database.js';
import {
  getTokensToMonitor,
  updateTokenHigh,
  updateTokenLow,
  markTakeProfit,
  markStopLoss
} from '../services/tokenService.js';
import { fetchTokenPrice } from '../services/solanaTrackerService.js';

const processMonitoring = async () => {
  const tokens = await getTokensToMonitor();
  console.log(tokens)
  if (tokens.length === 0) {
    console.log('.');
    return;
  }

  for (const token of tokens) {
    try {
      const currentPrice = await fetchTokenPrice(token.mint);
      const now = Math.floor(Date.now() / 1000);

      if (currentPrice > token.price && currentPrice > token.highest_price) {
        await updateTokenHigh(token.mint, currentPrice, now);
        console.log(`📈 New high for ${token.mint}: ${currentPrice}`);
      } else if (currentPrice < token.price && currentPrice < token.lowest_price) {
        await updateTokenLow(token.mint, currentPrice, now);
        console.log(`📉 New low for ${token.mint}: ${currentPrice}`);
      }

      const changeRatio = currentPrice / token.price;
      if (changeRatio >= 2) {
        await markTakeProfit(token.mint);
        console.log(`🎯 TP HIT for ${token.mint}`);
      } else if (changeRatio <= 0.5) {
        await markStopLoss(token.mint);
        console.log(`💥 SL HIT for ${token.mint}`);
      }

      await new Promise((r) => setTimeout(r, 1500)); // delay antar token
    } catch (err) {
      console.error(`Error monitoring ${token.mint}:`, err.message);
    }
  }
};

const main = async () => {
  await sequelize.authenticate();
  console.log('✅ Database connected. Starting monitoring bot...');
  await processMonitoring();
  setInterval(processMonitoring, 30_000);
};

main();
