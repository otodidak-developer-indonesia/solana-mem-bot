// src/utils/telegram.js
import TelegramBot from 'node-telegram-bot-api';
import dotenv from 'dotenv';
dotenv.config();

const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: false });
const chatId = process.env.TELEGRAM_CHAT_ID;

import { countTP, countSL } from '../services/tokenService.js';

export const sendTelegramNotification = async (mint, price, status = 'BUY') => {
  let title = '✅ Token Layak Dibeli Ditemukan!';
  if (status === 'TP') title = '🎯 TAKE PROFIT Hit!';
  if (status === 'SL') title = '💥 STOP LOSS Triggered!';

  const tp = await countTP();
  const sl = await countSL();
  const total = tp + sl;
  const ratio = total > 0 ? ((tp / total) * 100).toFixed(2) : '0.00';

  const message = `
${title}
- Token Mint: ${mint}
- Harga Sekarang: ${price}
- Total TP: ${tp}
- Total SL: ${sl}
- Win Rate: ${ratio}%
  `;

  const keyboard = {
    inline_keyboard: [[
      {
        text: "Lihat di gmgn.ai",
        url: `https://gmgn.ai/sol/token/${mint}`,
      }
    ]]
  };

  try {
    await bot.sendMessage(chatId, message, {
      reply_markup: JSON.stringify(keyboard),
    });
    console.log(`📩 Telegram (${status}) sent for ${mint}`);
  } catch (err) {
    console.error(`❌ Failed to send Telegram (${status}): ${err.message}`);
  }
};
