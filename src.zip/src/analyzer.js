const connection = require('./db');
const { saveTransaction } = require('./transaction');

async function evaluateTokenAndSave(token) {
  const pool = token.pools?.[0];
  if (!pool) return null;

  const now = Date.now();
  const tokenAgeMinutes = (now - pool.createdAt) / (1000 * 60);

  const marketCapSOL = pool.marketCap?.quote ?? 0;
  const liquiditySOL = pool.liquidity?.quote ?? 0;
  const volume = pool.txns?.volume ?? 0;

  const buys = pool.txns?.buys ?? 0;
  const sells = pool.txns?.sells ?? 0;
  const totalTx = pool.txns?.total ?? 1;
  const buyRatio = (buys / totalTx) * 100;

  const devHasSold = sells > 0 && token.token?.creation?.creator === pool.deployer;
  const isRenounced = pool.security?.freezeAuthority === null && pool.security?.mintAuthority === null;
  const socialOk = token.token.strictSocials?.twitter != null;

  const priceUsd = pool.price?.usd ?? 0;
  const minPrice = 0.00001;
  const maxPrice = 0.01;

  if (priceUsd < minPrice || priceUsd > maxPrice) {
    return null;
  }

  const result = {
    marketCapOk: marketCapSOL >= 20 && marketCapSOL <= 5000,
    buyRatioOk: buyRatio >= 50,
    liquidityOk: liquiditySOL >= 1,
    ageOk: tokenAgeMinutes <= 120,
    devNotSelling: !devHasSold,
    renouncedOk: isRenounced,
    volumeOk: volume >= 1000,
    socialOk,
  };

  if (Object.values(result).every(Boolean)) {
    const tokenData = {
      name: token.token.name,
      symbol: token.token.symbol,
      price: pool.price.usd ?? null,
      volume,
      marketCap: pool.marketCap.usd ?? null,
      buyRatio,
      liquidity: liquiditySOL,
      ageMinutes: tokenAgeMinutes,
      devNotSelling: !devHasSold,
      renounced: isRenounced,
      volumeOk: result.volumeOk,
      socialOk: result.socialOk,
      mintAddress: token.token.mint,
    };

    for (const k in tokenData) {
      if (tokenData[k] === undefined) tokenData[k] = null;
    }

    const query = `
      INSERT INTO tokens
      (name, symbol, price, volume, marketCap, buyRatio, liquidity, ageMinutes, devNotSelling, renounced, volumeOk, socialOk, mintAddress)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        price = VALUES(price),
        volume = VALUES(volume),
        marketCap = VALUES(marketCap),
        buyRatio = VALUES(buyRatio),
        liquidity = VALUES(liquidity),
        ageMinutes = VALUES(ageMinutes),
        devNotSelling = VALUES(devNotSelling),
        renounced = VALUES(renounced),
        volumeOk = VALUES(volumeOk),
        socialOk = VALUES(socialOk)
    `;

    const values = [
      tokenData.name,
      tokenData.symbol,
      tokenData.price,
      tokenData.volume,
      tokenData.marketCap,
      tokenData.buyRatio,
      tokenData.liquidity,
      tokenData.ageMinutes,
      tokenData.devNotSelling,
      tokenData.renounced,
      tokenData.volumeOk,
      tokenData.socialOk,
      tokenData.mintAddress,
    ];

    return new Promise((resolve, reject) => {
      connection.execute(query, values, (err, results) => {
        if (err) {
          return reject(err);
        }

        const tokenId = results.insertId;
        if (!tokenId) {
          return reject(new Error('Token ID not found'));
        }

        const quantity = tokenData.price ? 3 / tokenData.price : 0;

        saveTransaction(tokenId, token, tokenData.price, quantity)
          .then(() => resolve(result))
          .catch(reject);
      });
    });
  }

  return result;
}

async function evaluateTokens(tokens) {
  const criteriaKeys = [
    "marketCapOk",
    "buyRatioOk",
    "liquidityOk",
    "ageOk",
    "devNotSelling",
    "renouncedOk",
    "volumeOk",
    "socialOk",
  ];

  const summary = {};
  criteriaKeys.forEach(key => {
    summary[key] = { true: 0, false: 0 };
  });

  const results = await Promise.all(
    tokens.map(async (token) => {
      const result = await evaluateTokenAndSave(token);
      if (!result) return null;

      for (const key of criteriaKeys) {
        if (key in result) {
          summary[key][result[key] ? "true" : "false"]++;
        }
      }

      return result;
    })
  );

  const filteredResults = results.filter(Boolean);

  console.log("\nSummary of criteria match:");
  console.table(summary);

  return filteredResults;
}

module.exports = {
  evaluateTokens,
};
