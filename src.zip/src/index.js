// src/index.js
import { fork } from 'child_process';
import path from 'path';
import dotenv from 'dotenv';

const bots = ['screening', 'checking', 'monitoring'];

bots.forEach((bot) => {
  const proc = fork(path.resolve(`./bots/${bot}.js`), [], {
    stdio: ['inherit', 'pipe', 'pipe', 'ipc'],
  });

  proc.stdout.on('data', (data) => {
    process.stdout.write(`[${bot.toUpperCase()}] ${data}`);
  });

  proc.stderr.on('data', (data) => {
    process.stderr.write(`[${bot.toUpperCase()} ERROR] ${data}`);
  });

  proc.on('exit', (code) => {
    console.log(`[${bot.toUpperCase()}] exited with code ${code}`);
  });
});
