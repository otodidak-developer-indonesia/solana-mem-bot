const axios = require('axios');

async function fetchNewTokens() {
  try {
    const res = await axios.get('https://data.solanatracker.io/tokens/latest', {
      headers: {
        Accept: 'application/json',
        'x-api-key': process.env.API_KEY_SOLANATRACKER,
      },
      timeout: 10000,
    });
    return res.data || [];
  } catch (error) {
    console.error('Error fetching new tokens:', error.message);
    return [];
  }
}

async function getPricesForMultipleTokens(mintAddresses) {
  if (!mintAddresses.length) return {};
  try {
    const tokensParam = mintAddresses.join(',');
    const url = `https://data.solanatracker.io/price/multi?tokens=${encodeURIComponent(tokensParam)}`;
    const res = await axios.get(url, {
      headers: {
        Accept: 'application/json',
        'x-api-key': process.env.API_KEY_SOLANATRACKER,
      },
      timeout: 10000,
    });
    return res.data || {};
  } catch (error) {
    console.error('Error fetching prices:', error.message);
    return {};
  }
}

module.exports = {
  fetchNewTokens,
  getPricesForMultipleTokens,
};
