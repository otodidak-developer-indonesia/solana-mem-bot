require('dotenv').config();
const { monitorTrailingStop } = require('./src/monitoring');
const { simulateWalletBalanceAndSave } = require('./src/walletSimulator');
const { monitorWinrateAndProfit } = require('./src/profitMonitor');

async function trailingStopRunner() {
  await monitorTrailingStop();
  await simulateWalletBalanceAndSave();
  await monitorWinrateAndProfit();
}

trailingStopRunner();
setInterval(trailingStopRunner, 15000); // interval 15 detik
