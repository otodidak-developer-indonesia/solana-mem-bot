require('dotenv').config();
const connection = require('./src/db').promise();

function round2(num) {
  return Math.round(num * 100) / 100;
}

async function fetchComparisonData(limit = 100) {
  try {
    const [rows] = await connection.query(`
      SELECT 
        t.id AS transaction_id,
        t.mint_address,
        tokens.symbol,
        tokens.name,
        t.purchase_price,
        t.sell_price,
        t.quantity,
        t.quantity_sold,
        t.partial_sold,
        t.is_sold,
        t.purchase_time,
        t.sell_time,
        ROUND(((t.sell_price - t.purchase_price) * t.quantity_sold), 8) AS realized_profit,
        ROUND(((t.sell_price - t.purchase_price) / NULLIF(t.purchase_price, 0)) * 100, 2) AS percent_gain,
        tokens.price,
        tokens.volume,
        tokens.liquidity,
        tokens.marketCap
      FROM transactions t
      JOIN tokens ON tokens.id = t.token_id
      WHERE t.is_sold = 1
      ORDER BY t.sell_time DESC
      LIMIT ?
    `, [limit]);

    if (!rows.length) {
      console.log('No sold transactions found.');
      return;
    }

    // Fungsi untuk hitung volume to marketCap dalam persen
    function calcVolumeMarketCapPercent(volume, marketCap) {
      if (!volume || !marketCap || marketCap == 0) return 0;
      return (Number(volume) / Number(marketCap)) * 100;
    }

    // Pisahkan data rugpull dan profit tinggi
    const rugpulls = rows.filter(r => r.sell_price !== null && Number(r.sell_price) <= 0.0000001);
    const profitHigh = rows.filter(r => r.sell_price !== null && Number(r.sell_price) >= 2 * Number(r.purchase_price));

    console.log('\n=== Rugpull Tokens ===');
    console.table(rugpulls.map(r => ({
      ID: r.transaction_id,
      Symbol: r.symbol,
      Name: r.name,
      'Purchase Price': Number(r.purchase_price).toFixed(8),
      'Sell Price': Number(r.sell_price).toFixed(8),
      Quantity: Number(r.quantity_sold),
      'Realized Profit': round2(Number(r.realized_profit)),
      'Percent Gain (%)': round2(Number(r.percent_gain)),
      Liquidity: round2(Number(r.liquidity)),
      Volume: r.volume,
      MarketCap: round2(Number(r.marketCap)),
      'Vol/MarketCap (%)': round2(calcVolumeMarketCapPercent(r.volume, r.marketCap)),
    })));

    console.log('\n=== Profit > 100% Tokens ===');
    console.table(profitHigh.map(r => ({
      ID: r.transaction_id,
      Symbol: r.symbol,
      Name: r.name,
      'Purchase Price': Number(r.purchase_price).toFixed(8),
      'Sell Price': Number(r.sell_price).toFixed(8),
      Quantity: Number(r.quantity_sold),
      'Realized Profit': round2(Number(r.realized_profit)),
      'Percent Gain (%)': round2(Number(r.percent_gain)),
      Liquidity: round2(Number(r.liquidity)),
      Volume: r.volume,
      MarketCap: round2(Number(r.marketCap)),
      'Vol/MarketCap (%)': round2(calcVolumeMarketCapPercent(r.volume, r.marketCap)),
    })));

  } catch (error) {
    console.error('Error fetching comparison data:', error);
  } finally {
    connection.end();
  }
}

if (require.main === module) {
  fetchComparisonData();
}

module.exports = { fetchComparisonData };
