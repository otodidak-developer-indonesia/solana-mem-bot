require('dotenv').config();
const connection = require('./src/db').promise();

function round2(num) {
  return Math.round(num * 100) / 100;
}

async function monitorTransactionHistory() {
  try {
    const [rows] = await connection.query(`
      SELECT 
        t.id,
        t.mint_address,
        tokens.symbol,
        t.purchase_price,
        t.sell_price,
        t.purchase_time,
        t.sell_time,
        ROUND(((t.sell_price - t.purchase_price) * t.quantity_sold), 8) AS realized_profit,
        ROUND(((t.sell_price - t.purchase_price) / NULLIF(t.purchase_price, 0)) * 100, 2) AS percent_gain
      FROM transactions t
      JOIN tokens ON tokens.id = t.token_id
      WHERE t.is_sold = 1 OR t.partial_sold = 1
      ORDER BY t.sell_time DESC
      LIMIT 100
    `);

    if (!rows.length) {
      console.log('No completed transactions found.');
      return;
    }

    // Tampilkan tabel
    console.table(rows.map(row => {
      const realizedProfit = row.realized_profit !== null ? round2(Number(row.realized_profit)) : 0;
      const percentGainNum = row.percent_gain !== null ? round2(Number(row.percent_gain)) : null;

      return {
        ID: row.id,
        Symbol: row.symbol,
        Mint: row.mint_address,
        'Purchase Price': Number(row.purchase_price).toFixed(8),
        'Sell Price': row.sell_price ? Number(row.sell_price).toFixed(8) : null,
        'Purchase Time': row.purchase_time,
        'Sell Time': row.sell_time,
        'Realized Profit': realizedProfit,
        'Percent Gain (%)': percentGainNum !== null ? percentGainNum : 'N/A',
      };
    }));

    // Hitung total profit
    const totalProfit = rows.reduce((acc, row) => {
      const profit = row.realized_profit !== null ? Number(row.realized_profit) : 0;
      return acc + profit;
    }, 0);

    console.log('----------------------------------------');
    console.log(`Total Realized Profit: $${round2(totalProfit)}`);
    console.log('----------------------------------------');

  } catch (error) {
    console.error('Error monitoring transaction history:', error);
  } finally {
    connection.end();
  }
}

monitorTransactionHistory();
